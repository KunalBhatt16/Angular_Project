import { Component } from '@angular/core';
import { BookService } from '../book.service';

@Component({
	selector: 'app-delete-book',
	templateUrl: './delete-book.component.html',
	styleUrls: ['./delete-book.component.css']
})
export class DeleteBookComponent {
	bookId: string = '';

	constructor(private bookService: BookService) {}

	onSubmit() {
		this.bookService.deleteBook(this.bookId);
		this.bookId = '';
	}
}
