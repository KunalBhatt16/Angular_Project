export interface Book {
	bookId: string;
	authorName: string;
	bookName: string;
	quantity: number;
}
