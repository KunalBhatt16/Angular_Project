import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-return-book',
  templateUrl: './return-book.component.html',
  styleUrls: ['./return-book.component.css']
})
export class ReturnBookComponent implements OnInit {
  returnBookForm!: FormGroup;
  errorMessage!: string;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.returnBookForm = this.formBuilder.group({
      memberId: ['', Validators.required],
      bookId: ['', Validators.required],
      returnDate: ['', Validators.required]
    });
  }

  onSubmit() {
    const memberId = this.returnBookForm.value.memberId;
    const bookId = this.returnBookForm.value.bookId;
    const returnDate = new Date(this.returnBookForm.value.returnDate);
    const issueDate = new Date(); // assume issue date is current date
    const oneDay = 24 * 60 * 60 * 1000; // one day in milliseconds
    const daysLate = Math.round((returnDate.getTime() - issueDate.getTime()) / oneDay);

    if (daysLate > 0) {
      const fine = daysLate * 50; // 50 rupees per day late
      this.errorMessage = `You are ${daysLate} days late. You have been charged a fine of ${fine} rupees.`;
    } else {
      this.errorMessage = '';
    }

    // TODO: logic for returning the book and updating the library's inventory and member's record
  }
}
