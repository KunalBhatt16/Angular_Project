import { Component } from '@angular/core';
import { Book } from '../book.model';
import { BookService } from '../book.service';

@Component({
	selector: 'app-search',
	templateUrl: './search.component.html',
	styleUrls: ['./search.component.css']
})
export class SearchComponent {
	bookName: string = '';
	searchResults: Book[] = [];
	searchComplete = false;

	constructor(private bookService: BookService) {}

	onSubmit() {
		this.searchResults = this.bookService.searchBooks(this.bookName);
		this.searchComplete = true;
	}
}
