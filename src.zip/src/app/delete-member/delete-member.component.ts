import { Component } from '@angular/core';
import { MemberService } from '../member.service';

@Component({
	selector: 'app-delete-member',
	templateUrl: './delete-member.component.html',
	styleUrls: ['./delete-member.component.css']
})
export class DeleteMemberComponent {
	memberId: string = '';

	constructor(private memberService: MemberService) {}

	onSubmit() {
		this.memberService.deleteMember(this.memberId);
		this.memberId = '';
	}
}
