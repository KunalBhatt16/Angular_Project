import { Component } from '@angular/core';
import { Book } from '../book.model';
import { BookService } from '../book.service';

@Component({
	selector: 'app-add-book',
	templateUrl: './add-book.component.html',
	styleUrls: ['./add-book.component.css']
})
export class AddBookComponent {
	bookId: string = '';
	authorName: string = '';
	bookName: string = '';
	quantity: number = 0;

	constructor(private bookService: BookService) {}

	onSubmit() {
		const book: Book = {
			bookId: this.bookId,
			authorName: this.authorName,
			bookName: this.bookName,
			quantity: this.quantity
		};
		this.bookService.addBook(book);
		this.bookId = '';
		this.authorName = '';
		this.bookName = '';
		this.quantity = 0;
	}
}
