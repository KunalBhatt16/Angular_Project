import { Component } from '@angular/core';
import { ret } from '../ret.model';
@Component({
	selector: 'app-issue-book',
	templateUrl: './issue-book.component.html',
	styleUrls: ['./issue-book.component.css']
})
export class IssueBookComponent{

  bookId: string = '';
  memberId: string = '';
  returnDate: string = '';
  errorMessage: string = '';

  onSubmit() {
    // Validate return date
    const returnDateMs = new Date(this.returnDate).getTime();
    const twoWeeksMs = 2 * 7 * 24 * 60 * 60 * 1000;
    const maxReturnDateMs = Date.now() + twoWeeksMs;
  
    if (returnDateMs > maxReturnDateMs) {
      this.errorMessage = 'Return date cannot be more than 2 weeks from today';
      return;
    }

}
}