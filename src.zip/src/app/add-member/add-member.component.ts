import { Component } from '@angular/core';
import { Member } from '../member.model';
import { MemberService } from '../member.service';

@Component({
	selector: 'app-add-member',
	templateUrl: './add-member.component.html',
	styleUrls: ['./add-member.component.css']
})
export class AddMemberComponent {
	memberId: string = '';
	memberName: string = '';
	memberPhone: string = '';
	memberArea: string = '';

	constructor(private memberService: MemberService) {}

	onSubmit() {
		const member: Member = {
			memberId: this.memberId,
			memberName: this.memberName,
			memberPhone: this.memberPhone,
			memberArea: this.memberArea
		};
		this.memberService.addMember(member);
		this.memberId = '';
		this.memberName = '';
		this.memberPhone = '';
		this.memberArea = '';
	}
}
