import { Injectable } from '@angular/core';
import { Book } from './book.model';

@Injectable({
	providedIn: 'root'
})
export class BookService {
	books: Book[] = [];

	addBook(book: Book) {
		this.books.push(book);
	}

	deleteBook(bookId: string) {
		this.books = this.books.filter(book => book.bookId !== bookId);
	}

  searchBooks(bookName: string) {
		return this.books.filter(book => book.bookName.toLowerCase().includes(bookName.toLowerCase()) && book.quantity > 0);
	}

  getBookByName(bookName: string) {
		return this.books.find(book => book.bookName.toLowerCase() === bookName.toLowerCase());
	}
  issueBook(bookId: string, quantity: number) {
		const bookIndex = this.books.findIndex(book => book.bookId === bookId);
		if (bookIndex !== -1) {
			this.books[bookIndex].quantity -= quantity;
		}
}
}