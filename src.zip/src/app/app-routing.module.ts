import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookComponent } from './add-book/add-book.component';
import { HomeComponent } from './home/home.component';
import { DeleteBookComponent } from './delete-book/delete-book.component';
import { AddMemberComponent } from './add-member/add-member.component';
import { DeleteMemberComponent } from './delete-member/delete-member.component';
import { SearchComponent } from './search/search.component';
import { IssueBookComponent } from './issue-book/issue-book.component';
import { ReturnBookComponent } from './return-book/return-book.component';

const routes: Routes = [
  {path:'add-book',component:AddBookComponent},
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'delete-book',component:DeleteBookComponent},
  {path:'add-member',component:AddMemberComponent},
  {path:'delete-member',component:DeleteMemberComponent},
  {path:'search',component:SearchComponent},
  {path:'issue-book',component:IssueBookComponent},
  {path:'return-book',component:ReturnBookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
