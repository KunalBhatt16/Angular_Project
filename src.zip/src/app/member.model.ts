export interface Member {
	memberId: string;
	memberName: string;
	memberPhone: string;
	memberArea: string;
}
