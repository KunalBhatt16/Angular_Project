export interface ret{
    returnDate: string;
    errorMessage: string;
}