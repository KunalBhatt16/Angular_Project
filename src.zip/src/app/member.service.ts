import { Injectable } from '@angular/core';
import { Member } from './member.model';

@Injectable({
	providedIn: 'root'
})
export class MemberService {
	members: Member[] = [];

	addMember(member: Member) {
		this.members.push(member);
	}

	deleteMember(memberId: string) {
		this.members = this.members.filter(member => member.memberId !== memberId);
	}
}
